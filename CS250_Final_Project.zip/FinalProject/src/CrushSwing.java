import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.border.LineBorder;

public class CrushSwing implements MouseListener {
	public JFrame mainFrame;
	private static int score = 0;
	private int turnCount = 10;
	private int scoreLimit = 2000;
	private static CrushCell[][] arrCells; // start at 9 row 7 col
	static CrushCell swap = null;
	private JLabel lblScore;
	private JLabel lblTurnCount;
	private JLabel lblScoreLimit;
	

	/**
	 * Launch the application.
	 */

	/**
	 * Create the application.
	 */

	public CrushSwing() {
		initialize();
	}

	{

		score = 0;

	}

	/**
	 * Initialize the contents of the frame.
	 */

	public static boolean hasGray() { // return true if any cell in array is gray
		for (int i = 0; i < 9; i++) {
			for (int j = 0; j < 7; j++) {
				if (arrCells[i][j].isGray()) {
					return true;
				}
			}
		}
		return false;
	}

	public void drop() { // generate random colors on the top row of cleared cells, and drop colored
		// cells to fill gray slots
		while (hasGray()) {
			for (int i = 0; i < 9; i++) {
				for (int j = 0; j < 7; j++) {
					if (arrCells[i][j].isGray()) 
						if (arrCells[i][j].getRowid() == 0) {
							arrCells[i][j].setColorid((int) (Math.random() * 6 + 1));
							arrCells[i][j].setSymbolid(0);// 0 = "-"
						} else {
						arrCells[i][j].setColorid(arrCells[i - 1][j].getColorid());
						arrCells[i - 1][j].setColorid(0);
						arrCells[i][j].setSymbolid(arrCells[i - 1][j].getSymbolid());
					}
					arrCells[i][j].setSymbol();
					arrCells[i][j].setColor();
				}
			}
		}
	}

	public static void special1(int k, int j) {
		arrCells[k][j].setSymbolid(0);
		if(k - 1 >= 0 && !arrCells[k-1][j].isGray()) {
			arrCells[k-1][j].setColorid(0);
			score += 40;
			if(arrCells[k-1][j].getSymbolid() == 1) {
				arrCells[k-1][j].setSymbolid(0);
				special1(k-1, j);
			}
			if(arrCells[k-1][j].getSymbolid() == 2) {
				arrCells[k-1][j].setSymbolid(0);
				special2(k-1, j);
			}
		}
		if(k-1 >= 0 && j + 1 < 7 && !arrCells[k-1][j+1].isGray()) {
			arrCells[k-1][j+1].setColorid(0);
			score += 40;
			if(arrCells[k-1][j+1].getSymbolid() == 1) {
				arrCells[k-1][j+1].setSymbolid(0);
				special1(k-1, j+1);
			}
			if(arrCells[k-1][j+1].getSymbolid() == 2) {
				arrCells[k-1][j+1].setSymbolid(0);
				special2(k-1, j+1);
			}
		}
		if(k - 1 >= 0 && j - 1 >= 0 && !arrCells[k-1][j-1].isGray()) {
			arrCells[k-1][j-1].setColorid(0);
			score += 40;
			if(arrCells[k-1][j-1].getSymbolid() == 1) {
				arrCells[k-1][j-1].setSymbolid(0);
				special1(k-1, j-1);
			}
			if(arrCells[k-1][j-1].getSymbolid() == 2) {
				arrCells[k-1][j-1].setSymbolid(0);
				special2(k-1, j-1);
			}
		}
		if(j - 1 >= 0 && !arrCells[k][j-1].isGray()) {
			arrCells[k][j-1].setColorid(0);
			score += 40;
			if(arrCells[k][j-1].getSymbolid() == 1) {
				arrCells[k][j-1].setSymbolid(0);
				special1(k, j-1);
			}
			if(arrCells[k][j-1].getSymbolid() == 2) {
				arrCells[k][j-1].setSymbolid(0);
				special2(k, j-1);
			}
		}
		if(j + 1 < 7 && !arrCells[k][j+1].isGray()) {
			arrCells[k][j+1].setColorid(0);
			score += 40;
			if(arrCells[k][j+1].getSymbolid() == 1) {
				arrCells[k][j+1].setSymbolid(0);
				special1(k, j+1);
			}
			if(arrCells[k][j+1].getSymbolid() == 2) {
				arrCells[k][j+1].setSymbolid(0);
				special2(k, j+1);
			}
		}
		if(k + 1 < 9 && j - 1 >= 0 && !arrCells[k+1][j-1].isGray()) {
			arrCells[k+1][j-1].setColorid(0);
			score += 40;
			if(arrCells[k+1][j-1].getSymbolid() == 1) {
				arrCells[k+1][j-1].setSymbolid(0);
				special1(k+1, j-1);
			}
			if(arrCells[k+1][j-1].getSymbolid() == 2) {
				arrCells[k+1][j-1].setSymbolid(0);
				special2(k+1, j-1);
			}
		}
		if(k + 1 < 9 && !arrCells[k+1][j].isGray()) {
			arrCells[k+1][j].setColorid(0);
			score += 40;
			if(arrCells[k+1][j].getSymbolid() == 1) {
				arrCells[k+1][j].setSymbolid(0);
				special1(k+1, j);
			}
			if(arrCells[k+1][j].getSymbolid() == 2) {
				arrCells[k+1][j].setSymbolid(0);
				special2(k+1, j);
			}
		}
		if(k + 1 < 0 && j + 1 < 7 && !arrCells[k+1][j+1].isGray()) {
			arrCells[k+1][j+1].setColorid(0);
			score += 40;
			if(arrCells[k+1][j+1].getSymbolid() == 1) {
				arrCells[k+1][j+1].setSymbolid(0);
				special1(k+1, j+1);
			}
			if(arrCells[k+1][j+1].getSymbolid() == 2) {
				arrCells[k+1][j+1].setSymbolid(0);
				special2(k+1, j+1);
			}
		}
	}
	public static void special2(int k, int j) {
		arrCells[k][j].setSymbolid(0);
		for(int q = 0; q < 9; q++) {
			if(!arrCells[q][j].isGray()) {
				arrCells[q][j].setColorid(0);
				score+=40;
				if(arrCells[q][j].getSymbolid() == 1) {
					arrCells[q][j].setSymbolid(0);
					special1(q, j);
				}
				if(arrCells[q][j].getSymbolid() == 2) {
					arrCells[q][j].setSymbolid(0);
					special2(q,j);
				}
			}
		}
		for(int q = 0; q < 7; q++) {
			if(!arrCells[k][q].isGray()) {
				arrCells[k][q].setColorid(0);
				score +=40;
			}
			if(arrCells[k][q].getSymbolid() == 1) {
				arrCells[k][q].setSymbolid(0);
				special1(k, q);
			}
			if(arrCells[k][q].getSymbolid() == 2) {
				arrCells[k][q].setSymbolid(0);
				special2(k,q);
			}
		}
	}
	public boolean clear() {
		boolean match = false; 		//boolean of whether there are 3 or more arrCells in a row
		for (int i = 0; i < arrCells.length; i++) {
			for (int j = 0; j < arrCells[i].length; j++) {
				int curCellColor = arrCells[i][j].getColorid();
				int verCount = 1;
				int hozCount = 1;
				while (verCount + i < arrCells.length 		
						&& arrCells[i][j].getColorid() == arrCells[i + verCount][j].getColorid()
						&& arrCells[i][j].getColorid() > 0) {
					verCount++;
				}
				if (verCount >= 3) {
					score += verCount * 40;
					match = true;
					for (int k = i; k < i + verCount; k++) {
						arrCells[k][j].setColorid(0);
						if(arrCells[k][j].getSymbolid() == 1) {
							special1(k, j);
						}
						if(arrCells[k][j].getSymbolid() == 2) {
							special2(k,j);
						}
						lblScore.setText("Score: " + score);
					}
					if(verCount == 4) {
						arrCells[i+(verCount/2+1)][j].setSymbolid(1);
						arrCells[i+(verCount/2+1)][j].setColorid(curCellColor);
					}
					if(verCount == 5) {
						arrCells[i+(verCount/2+1)][j].setSymbolid(2);
						arrCells[i+(verCount/2+1)][j].setColorid(curCellColor);
					}
				}
				while (hozCount + j < arrCells[i].length
						&& arrCells[i][j].getColorid() == arrCells[i][j + hozCount].getColorid()
						&& arrCells[i][j].getColorid() > 0) {
					hozCount++;
				}

				if (hozCount >= 3) {
					score += hozCount * 40;
					match = true;
					for (int k = j; k < j + hozCount; k++) {
						arrCells[i][k].setColorid(0);
						if(arrCells[i][k].getSymbolid() == 1) {
							special1(i, k);
						}
						if(arrCells[i][k].getSymbolid() == 2) {
							special2(i, k);
						}
						lblScore.setText("Score: " + score);
					}
					if(hozCount == 4) {
						arrCells[i][j+(hozCount/2+1)].setSymbolid(1);
						arrCells[i][j+(hozCount/2+1)].setColorid(curCellColor);
					}
					if(hozCount == 5) {
						arrCells[i][j+(hozCount/2+1)].setSymbolid(2);
						arrCells[i][j+(hozCount/2+1)].setColorid(curCellColor);
					}
				}
			}

		}
		return match;
	}

	private void initialize() {
		mainFrame = new JFrame();
		mainFrame.setBounds(100, 100, 500, 600);
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	

		JPanel upper = new JPanel();
		mainFrame.getContentPane().add(upper, BorderLayout.NORTH);

		lblScore = new JLabel("\"\"");
		upper.add(lblScore);

		JPanel center = new JPanel();
		center.setBorder(new LineBorder(Color.BLACK, 2));
		mainFrame.getContentPane().add(center, BorderLayout.CENTER);
		center.setLayout(new GridLayout(9, 7, 0, 0));
		mainFrame.setLocationRelativeTo(null);

		arrCells = new CrushCell[9][7];
		for (int i = 0; i < arrCells.length; i++) {
			for (int j = 0; j < arrCells[i].length; j++) {
				arrCells[i][j] = new CrushCell("");
				arrCells[i][j].setFont(new Font("Arial", Font.PLAIN, 30));
				center.add(arrCells[i][j]);
				arrCells[i][j].setColorid((int) (Math.random() * 6 + 1));
				arrCells[i][j].setRowid(i);
				arrCells[i][j].setColid(j);
				arrCells[i][j].addMouseListener(this);
			}
		}

		lblTurnCount = new JLabel("\"\"");
		upper.add(lblTurnCount);

		lblScoreLimit = new JLabel("\"\"");
		upper.add(lblScoreLimit);

		clear();
		while (hasGray()) {
			drop();
			clear();
		}
		for (int i = 0; i < arrCells.length; i++) {
			for (int j = 0; j < arrCells[i].length; j++) {
				arrCells[i][j].setSymbolid(0);
			}
			}
		score = 0;
		lblScore.setText("Score: " + score);
		lblTurnCount.setText("Turns Left: " + turnCount);
		lblScoreLimit.setText("Target Score: " + scoreLimit);

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		if (swap == null) {
			swap = (CrushCell) e.getSource();
			swap.setBorder(BorderFactory.createLineBorder(Color.black, 5, true));

		} else if (swap.getRowid() - ((CrushCell) e.getSource()).getRowid() >= -1
				&& swap.getRowid() - ((CrushCell) e.getSource()).getRowid() <= 1
				&& swap.getColid() - ((CrushCell) e.getSource()).getColid() >= -1
				&& swap.getColid() - ((CrushCell) e.getSource()).getColid() <= 1) {

			turnCount--;
			lblTurnCount.setText("Turn Count: " + turnCount);
			if (turnCount == 0) {
				System.out.println("Game Over");
				return;
			}

			int tempColor = swap.getColorid();
			int tempSymbol = swap.getSymbolid();
			swap.setColorid(((CrushCell) e.getSource()).getColorid());
			swap.setSymbolid(((CrushCell) e.getSource()).getSymbolid());
			
			
			((CrushCell) e.getSource()).setColorid(tempColor);
			((CrushCell) e.getSource()).setSymbolid(tempSymbol);
			swap.setBorderPainted(false);

			if (!clear()) {
				tempSymbol = swap.getSymbolid();
				swap.setColorid(((CrushCell) e.getSource()).getColorid());
				swap.setSymbolid(((CrushCell) e.getSource()).getSymbolid());
				((CrushCell) e.getSource()).setColorid(tempColor);
				((CrushCell) e.getSource()).setSymbolid(tempSymbol);
				swap.setBorderPainted(false);
			}

			clear();
			while (hasGray()) {
				if (score >= scoreLimit) {
					System.out.println("You Win");
				}
				drop();
				clear();

			}

			swap = null;

		} else {
			System.err.println("Illegal Move!");
			swap.setBorderPainted(false);
			swap = null;
		}

	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}
}

