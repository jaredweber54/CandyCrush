
import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import javax.swing.JPanel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.border.LineBorder;
import javax.swing.border.CompoundBorder;

public class CrushMenu implements ActionListener {

	public JFrame menuFrame;
	public JButton btnStart;
	CrushSwing mainMenu = new CrushSwing();

	public CrushMenu() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		menuFrame = new JFrame();
		menuFrame.getContentPane().setBackground(Color.BLACK);
		menuFrame.setTitle("Candy Crush by Nathan Struble and Jared Weber");

		JPanel panel = new JPanel();
		panel.setBorder(new CompoundBorder(
				new CompoundBorder(new LineBorder(new Color(0, 255, 0), 3),
						new CompoundBorder(new LineBorder(new Color(255, 0, 0), 3, true),
								new CompoundBorder(new LineBorder(new Color(255, 200, 0), 3),
										new LineBorder(new Color(255, 255, 0), 3)))),
				new LineBorder(new Color(0, 0, 255), 3)));
		panel.setBackground(Color.BLACK);
		menuFrame.getContentPane().add(panel, BorderLayout.CENTER);
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.columnWidths = new int[] { 484, 0 };
		gbl_panel.rowHeights = new int[] { 187, 187, 0 };
		gbl_panel.columnWeights = new double[] { 1.0, Double.MIN_VALUE };
		gbl_panel.rowWeights = new double[] { 0.0, 0.0, Double.MIN_VALUE };
		panel.setLayout(gbl_panel);

		ImageIcon title = new ImageIcon("src/candy.png");
		JLabel lblTitle = new JLabel();
		lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitle.setFont(new Font("Agency FB", Font.PLAIN, 98));
		lblTitle.setForeground(Color.RED);
		lblTitle.setIcon(title);
		GridBagConstraints gbc_lblTitle = new GridBagConstraints();
		gbc_lblTitle.fill = GridBagConstraints.BOTH;
		gbc_lblTitle.insets = new Insets(0, 0, 5, 0);
		gbc_lblTitle.gridx = 0;
		gbc_lblTitle.gridy = 0;
		panel.add(lblTitle, gbc_lblTitle);

		ImageIcon start = new ImageIcon("src/startCandy.png");
		btnStart = new JButton();
		btnStart.setFont(new Font("Agency FB", Font.PLAIN, 50));
		btnStart.setForeground(Color.RED);
		btnStart.setBackground(Color.GREEN);
		btnStart.setIcon(start);
		btnStart.setBorder(new CompoundBorder(
				new CompoundBorder(new LineBorder(new Color(0, 255, 0), 3),
						new CompoundBorder(new LineBorder(new Color(255, 0, 0), 3, true),
								new CompoundBorder(new LineBorder(new Color(255, 200, 0), 3),
										new LineBorder(new Color(255, 255, 0), 3)))),
				new LineBorder(new Color(0, 0, 255), 3)));
		GridBagConstraints gbc_btnStart = new GridBagConstraints();
		gbc_btnStart.gridx = 0;
		gbc_btnStart.gridy = 1;
		panel.add(btnStart, gbc_btnStart);
		btnStart.addActionListener(this);
		menuFrame.setBounds(100, 100, 500, 600);
		menuFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		menuFrame.setLocationRelativeTo(null);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == btnStart) {
			menuFrame.setVisible(false);
			mainMenu.mainFrame.setVisible(true);

		}

	}

}
