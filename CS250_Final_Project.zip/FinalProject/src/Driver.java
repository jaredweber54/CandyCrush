import java.awt.EventQueue;

public class Driver {

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CrushSwing mainWindow = new CrushSwing();
					mainWindow.mainFrame.setVisible(false);
					CrushMenu menuWindow = new CrushMenu();
					menuWindow.menuFrame.setVisible(true);

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});

	}
}
