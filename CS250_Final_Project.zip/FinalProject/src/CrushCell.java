import java.awt.Color;
import javax.swing.JButton;

public class CrushCell extends JButton {
	private static final long serialVersionUID = 679824905924210965L;
	int rowid;
	int colid;
	int colorid;
	int symbolid;

	public CrushCell(String s) {
		super(s);
		colorid = 0;
		setFocusPainted(false);
	}

	public void setRowid(int i) { rowid = i;}

	public int getRowid() { return rowid; }

	public int getColorid() { return colorid; }

	public void setColorid(int i) {colorid = i; setColor(); }

	public int getSymbolid() {	return symbolid; }

	public void setSymbolid(int symbolid) {	this.symbolid = symbolid; setSymbol(); }
	
	public int getColid() {	return colid; }

	public void setColid(int col) {	this.colid = col;}

	public boolean isGray() {
		if (colorid == 0) return true;
		else return false;
		
	}
	
	public void setSymbol() {
		switch(symbolid) {
		case 0:
			this.setText("");
			break;
		case 1:
			this.setText("o");
			break;
		case 2:
			this.setText("+");
		}
	}

	public void setColor() {
		switch (colorid) {
		case 0:
			this.setBackground(new Color(169, 169, 169));
			break;
		case 1:
			this.setBackground(new Color(255, 0, 0));
			break;
		case 2:
			this.setBackground(new Color(0, 255, 0));
			break;
		case 3:
			this.setBackground(new Color(0, 0, 255));
			break;
		case 4:
			this.setBackground(new Color(255, 255, 0));
			break;
		case 5:
			this.setBackground(new Color(255, 165, 0));
			break;
		case 6:
			this.setBackground(new Color(128, 0, 128));
			break;
		}
	}
}
